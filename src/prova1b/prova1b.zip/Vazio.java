package prova1b;

public class Vazio extends Exception {
	
	public Vazio(String message) {
		super(message);
	}

}
