package prova1b;

public class Nexiste extends Exception{

	public Nexiste (String message) {
		super(message);
	}
	}
