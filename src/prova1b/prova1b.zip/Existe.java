package prova1b;

public class Existe extends Exception{
	public Existe(String message) {
		super(message);
	}
}
